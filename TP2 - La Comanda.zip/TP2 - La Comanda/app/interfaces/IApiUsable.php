<?php
interface IApiUsable
{
	public function Alta($request, $response, $args);

}

?>

